package com.socialmediaweb.socialmediaweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialmediaWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocialmediaWebApplication.class, args);
	}

}
